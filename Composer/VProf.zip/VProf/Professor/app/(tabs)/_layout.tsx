import { Tabs } from 'expo-router';
import React from 'react';
import { Platform } from 'react-native';

import { HapticTab } from '@/components/HapticTab';
import { IconSymbol } from '@/components/ui/IconSymbol';
import TabBarBackground from '@/components/ui/TabBarBackground';
import { Colors } from '@/constants/Colors';
import { useColorScheme } from '@/hooks/useColorScheme';
import { FontAwesome } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';


export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarBackground: TabBarBackground,
        tabBarStyle: Platform.select({
          ios: {
            position: 'absolute',
          },
          default: {},
        }),
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} />,
         /* tabBarStyle: { display: 'none' },  // Hide the tab bar for Home screen*/

        }}
      />
      <Tabs.Screen
        name="quests"
        options={{
          title: 'Quests',
          tabBarIcon: ({ color }) => (
            <FontAwesome5 name="scroll" size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="student_quests"
        options={{
          title: 'Student Quests',
          tabBarIcon: ({ color }) => (
            <FontAwesome5 name="graduation-cap" size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="github"
        options={{
          title: 'GitHub',
          tabBarIcon: ({ color }) => (
            <FontAwesome name="github" size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="NFCReader"
        options={{
          title: 'NFC',
          tabBarIcon: ({ color }) => (
            <FontAwesome name="wifi" size={24} color={color} />
          ),
        }}
      />

    </Tabs>
  );
}
