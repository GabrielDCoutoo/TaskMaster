//Professor
// index.tsx
export const quest_url = 'http://192.168.43.98:8001';

//quests.tsx
export const BACKEND_URL2 = 'http://192.168.43.98:8001';

//student_quests.tsx
export const student_quest_url = "http://192.168.43.98:8001";


